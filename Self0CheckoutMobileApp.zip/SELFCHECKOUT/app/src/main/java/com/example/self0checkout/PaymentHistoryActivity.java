//package com.example.self0checkout;
//
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class PaymentHistoryActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_payment_history);
//
//        // Get the current user
//        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//        if (user != null) {
//            String userId = user.getUid();
//
//            // Reference to Firebase database
//            DatabaseReference paymentRef = FirebaseDatabase.getInstance().getReference("paymentHistory").child(userId);
//
//            // Listen for changes in the payment history
//            paymentRef.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                    // Clear previous payment history items
//                    LinearLayout paymentHistoryContainer = findViewById(R.id.paymentHistoryContainer);
//                    paymentHistoryContainer.removeAllViews();
//
//                    // Iterate through payment history data and add items dynamically to the layout
//                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                        PaymentHistory paymentHistory = snapshot.getValue(PaymentHistory.class);
//                        if (paymentHistory != null) {
//                            TextView textView = new TextView(PaymentHistoryActivity.this);
//                            textView.setText(paymentHistory.getAmount() + " - " + paymentHistory.getDateTime());
//                            paymentHistoryContainer.addView(textView);
//                        }
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//                    // Handle database error
//                    Log.e("PaymentHistory", "Error fetching payment history: " + databaseError.getMessage());
//                    Toast.makeText(PaymentHistoryActivity.this, "Error fetching payment history", Toast.LENGTH_SHORT).show();
//                }
//            });
//        }
//    }
//}
