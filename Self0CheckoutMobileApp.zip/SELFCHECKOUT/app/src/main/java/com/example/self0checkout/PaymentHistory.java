//package com.example.self0checkout;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class PaymentHistory extends AppCompatActivity {
//    private String amount;
//    private String dateTime;
//
//    public PaymentHistory() {
//        // Default constructor required for Firebase
//    }
//
//    public PaymentHistory(String amount, String dateTime) {
//        this.amount = amount;
//        this.dateTime = dateTime;
//    }
//
//    public String getAmount() {
//        return amount;
//    }
//
//    public String getDateTime() {
//        return dateTime;
//    }
//}
//
