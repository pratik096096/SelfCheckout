package com.example.self0checkout;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;

import android.text.InputType;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableLayout.LayoutParams;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;



public class Carting extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "CartActivity";
    private TextView textView1, textView2, textView3, textView4, textView, GrandTotal;
    private Button Button02;
    private DatabaseReference databaseReference1, unameref, unameref2, databaseReference3, databaseReference2;
    Query queryRef, queryRef1, queryRef2, queryRef3;
    private FirebaseAuth firebaseAuth;
    private TableLayout TableLayout;
    private TableRow tablerow1;
    int GTT = 0;
    String string1, string2, username;
    int string3, string4;
    private Boolean isstop = false;


    Boolean move = false;

    public static char[] getTotal() {
        return new char[0];
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carting);
        Button02 = (Button) findViewById(R.id.Button02);
        textView1 = (TextView) findViewById(R.id.textView1);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView3 = (TextView) findViewById(R.id.textView3);
        textView4 = (TextView) findViewById(R.id.textView4);
        GrandTotal = (TextView) findViewById(R.id.GrandTotal);
        TableLayout = (TableLayout) findViewById(R.id.myTableLayout);
        tablerow1 = (TableRow) findViewById(R.id.tablerow1);
        textView = (TextView) findViewById(R.id.textView);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Button02.setOnClickListener(this);
        databaseReference1 = FirebaseDatabase.getInstance().getReference();
        unameref = FirebaseDatabase.getInstance().getReference();
        databaseReference3 = FirebaseDatabase.getInstance().getReference();
        unameref2 = FirebaseDatabase.getInstance().getReference();
        databaseReference2 = FirebaseDatabase.getInstance().getReference();

        firebaseAuth = FirebaseAuth.getInstance();

        FirebaseUser user = firebaseAuth.getCurrentUser();
        queryRef1 = unameref.child("Users").orderByChild("userid").equalTo(user.getUid());

        queryRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    User user = postSnapshot.getValue(User.class);
                    username = user.getusername();

                    queryRef = databaseReference1.child("Carts").child(username);
                    queryRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            if (snapshot.hasChildren()) {
                                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                                    final Cart cart = postSnapshot.getValue(Cart.class);
                                    final TableRow tableRow1 = new TableRow(Carting.this);
                                    final TextView textView1 = new TextView(Carting.this);
                                    TextView textView2 = new TextView(Carting.this);
                                    TextView textView3 = new TextView(Carting.this);
                                    TextView textView4 = new TextView(Carting.this);

                                    assert cart != null;
                                    textView1.setText(cart.getPname());
                                    textView3.setText(cart.getPprice() + ".00");
                                    textView2.setText(cart.getPquantity() + "");
                                    textView4.setText(cart.getTotal() + ".00");

                                    textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                                    textView2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                                    textView3.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                                    textView4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);


                                    tableRow1.addView(textView1);
                                    tableRow1.addView(textView3);
                                    tableRow1.addView(textView2);
                                    tableRow1.addView(textView4);

                                    tableRow1.setPadding(0, 10, 0, 10);
                                    GTT = GTT + cart.getTotal();
                                    GrandTotal.setText("Total: " + GTT + " Rs.");
                                    TableLayout.addView(tableRow1, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                                    tableRow1.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {

//                                             int row_id= TableLayout.indexOfChild(tableRow1);
//                                             String str=Integer.toString(row_id);

                                            final String pid = cart.getPid();
                                            final int price = cart.getPprice();
                                            final String pname = cart.getPname();

                                            AlertDialog dialog = new AlertDialog.Builder(Carting.this)
                                                    .setCancelable(true)
                                                    .setTitle(pname)
                                                    .setMessage(string1)
                                                    .setPositiveButton("Delete Item", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int which) {
                                                            databaseReference2.child("Carts").child(username).child(pid).setValue(null);
                                                            Toast.makeText(Carting.this, pname + " Deleted from Cart", Toast.LENGTH_SHORT).show();
                                                            finish();
                                                            Intent intent = getIntent();
                                                            startActivity(intent);
                                                        }
                                                    })
                                                    .setNegativeButton("Modify Quantity", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int id) {
                                                            AlertDialog.Builder builder = new AlertDialog.Builder(Carting.this);
                                                            builder.setTitle("Enter New Quantity");
                                                            final EditText input = new EditText(Carting.this);
                                                            input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                                            builder.setView(input);
                                                            builder.setNeutralButton("Submit", new DialogInterface.OnClickListener() {
                                                                @Override
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    String pquantity1 = input.getText().toString().trim();
                                                                    int pquantity = Integer.parseInt(pquantity1);
                                                                    Cart cart = new Cart(pid, pname, price, pquantity);
                                                                    databaseReference3.child("Carts").child(username).child(pid).setValue(cart);
                                                                    finish();
                                                                    Intent intent = getIntent();
                                                                    startActivity(intent);
                                                                }
                                                            });
                                                            builder.create();
                                                            builder.show();
                                                        }
                                                    }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int id) {

                                                        }
                                                    })
                                                    .create();
                                            dialog.show();
                                        }
                                    });
                                }
                            } else {
                                tablerow1.setVisibility(View.VISIBLE);
                                textView.setVisibility(View.VISIBLE);
                                int imageResource = getResources().getIdentifier("@drawable/cartempt", null, getPackageName());
                                Drawable imageview = getResources().getDrawable(imageResource);
                                TableLayout.setBackground(imageview);

                                GrandTotal.setText("Oops No Item in Cart");
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_cart, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onClick(View v) {
        if (v == Button02) {
            AlertDialog.Builder builder = new AlertDialog.Builder(Carting.this);
            builder.setTitle("Confirmation to Proceed");
            builder.setMessage("You Won't be able to do changes again in Cart")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            startActivity(new Intent(Carting.this, Billing.class));
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            Intent intent = getIntent();
                            startActivity(intent);
                        }
                    });

            AlertDialog alert1 = builder.create();
            alert1.show();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_item_1) {
            AlertDialog dialog = new AlertDialog.Builder(Carting.this)
                    .setCancelable(true)
                    .setTitle("Confirmation")
                    .setMessage("Please Confirm to Clear Your Cart")
                    .setPositiveButton("Proceed", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            queryRef1 = databaseReference1.child("Carts").child(username);
                            queryRef1.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    for (DataSnapshot appleSnapshot : dataSnapshot.getChildren()) {
                                        appleSnapshot.getRef().removeValue();
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    Log.e(TAG, "onCancelled", databaseError.toException());
                                }
                            });
                            finish();
                            startActivity(new Intent(Carting.this, Carting.class));
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            finish();
                            startActivity(new Intent(Carting.this, Carting.class));
                        }
                    })
                    .create();
            dialog.show();
        } else if (id == R.id.menu_item_2) {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this, Login.class));
        } else {
            super.onOptionsItemSelected(item);
        }
        return false;
    }
}
//    private void saveCartItemsLocally() {
//        // Convert cartItems list to JSON
//        Gson gson = new Gson();
//        String jsonCartItems = gson.toJson(cartItems);
//
//        // Save JSON string to shared preferences
//        SharedPreferences sharedPreferences = getSharedPreferences("ReorderItems", MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.putString("cartItems", jsonCartItems);
//        editor.apply();
//    }
//
//    // Method to load cart items from Firebase
//    private void loadCartItems() {
//        Query queryRef = databaseReference1.child("Carts").child(username);
//        queryRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                cartItems.clear(); // Clear previous cart items
//                GTT = 0; // Reset total
//
//                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
//                    Cart cart = postSnapshot.getValue(Cart.class);
//                    cartItems.add(cart); // Add cart item to list
//
//                    // Add cart item to TableLayout
//                    // Your existing code...
//                }
//
//                // Calculate total and update UI
//                // Your existing code...
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.e(TAG, "Database Error: " + databaseError.getMessage());
//            }
//        });
//    }






//package com.example.self0checkout;
//
//import android.annotation.TargetApi;
//import android.app.AlertDialog;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.graphics.drawable.Drawable;
//import android.os.Build;
//import android.os.Bundle;
//
//import androidx.annotation.RequiresApi;
//
//import android.text.InputType;
//import android.util.Log;
//import android.util.TypedValue;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TableLayout;
//import android.widget.TableLayout.LayoutParams;
//import android.widget.TableRow;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.Query;
//import com.google.firebase.database.ValueEventListener;
//
//
//
//public class Carting extends AppCompatActivity implements View.OnClickListener {
//
//    private static final String TAG = "CartActivity";
//    public static int productTotal;
//
//    private TextView textView1, textView2, textView3, textView4, textView, GrandTotal;
//    private Button Button02;
//    private DatabaseReference databaseReference1, unameref, unameref2, databaseReference3, databaseReference2;
//    Query queryRef, queryRef1, queryRef2, queryRef3;
//    private FirebaseAuth firebaseAuth;
//    private TableLayout TableLayout;
//    private TableRow tablerow1;
//    int GTT = 0;
//    String string1, string2, username;
//    int string3, string4;
//    private Boolean isstop = false;
//
//
//    Boolean move = false;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_carting);
//        Button02 = (Button) findViewById(R.id.Button02);
//        textView1 = (TextView) findViewById(R.id.textView1);
//        textView2 = (TextView) findViewById(R.id.textView2);
//        textView3 = (TextView) findViewById(R.id.textView3);
//        textView4 = (TextView) findViewById(R.id.textView4);
//        GrandTotal = (TextView) findViewById(R.id.GrandTotal);
//        TableLayout = (TableLayout) findViewById(R.id.myTableLayout);
//        tablerow1 = (TableRow) findViewById(R.id.tablerow1);
//        textView = (TextView) findViewById(R.id.textView);
//
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//
//        Button02.setOnClickListener(this);
//        databaseReference1 = FirebaseDatabase.getInstance().getReference();
//        unameref = FirebaseDatabase.getInstance().getReference();
//        databaseReference3 = FirebaseDatabase.getInstance().getReference();
//        unameref2 = FirebaseDatabase.getInstance().getReference();
//        databaseReference2 = FirebaseDatabase.getInstance().getReference();
//
//        firebaseAuth = FirebaseAuth.getInstance();
//
//        FirebaseUser user = firebaseAuth.getCurrentUser();
//        queryRef1 = unameref.child("Users").orderByChild("userid").equalTo(user.getUid());
//
//        queryRef1.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
//                    User user = postSnapshot.getValue(User.class);
//                    username = user.getusername();
//
//                    queryRef = databaseReference1.child("Carts").child(username);
//                    queryRef.addValueEventListener(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(DataSnapshot snapshot) {
//                            if (snapshot.hasChildren()) {
//                                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
//                                    final Cart cart = postSnapshot.getValue(Cart.class);
//                                    final TableRow tableRow1 = new TableRow(Carting.this);
//                                    final TextView textView1 = new TextView(Carting.this);
//                                    TextView textView2 = new TextView(Carting.this);
//                                    TextView textView3 = new TextView(Carting.this);
//                                    TextView textView4 = new TextView(Carting.this);
//
//                                    final String pid = cart.getPid();
//                                    final String pname = cart.getPname();
//                                    final int pprice = cart.getPprice();
//                                    final int pquantity = cart.getPquantity();
//
//                                    textView1.setText(pname);
//                                    textView3.setText(pprice + ".00");
//                                    textView2.setText(pquantity + "");
//                                    int productTotal = pprice * pquantity;
//                                    textView4.setText(productTotal + ".00");
//
//                                    // Set text size
//                                    textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
//                                    textView2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
//                                    textView3.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
//                                    textView4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
//
//                                    // Add click listener for update quantity
//                                    textView2.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//                                            updateQuantity(pid, pname, pprice, textView2);
//                                        }
//                                    });
//
//                                    // Add click listener for remove item
//                                    final Drawable imgRemove = getResources().getDrawable(R.drawable.cartempt);
//                                    imgRemove.setBounds(0, 0, 60, 60);
//                                    final Button buttonRemove = new Button(Carting.this);
//                                    buttonRemove.setBackgroundDrawable(imgRemove);
//                                    buttonRemove.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//                                            removeItem(pid);
//                                            TableLayout.removeView(tableRow1);
//                                        }
//                                    });
//
//                                    tableRow1.addView(textView1);
//                                    tableRow1.addView(textView3);
//                                    tableRow1.addView(textView2);
//                                    tableRow1.addView(textView4);
//                                    tableRow1.addView(buttonRemove);
//
//                                    tableRow1.setPadding(0, 10, 0, 10);
//                                    GTT = GTT + productTotal;
//                                    GrandTotal.setText("Total: " + GTT + " Rs.");
//                                    TableLayout.addView(tableRow1, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
//                                }
//                            } else {
//                                textView.setText("Your Cart is Empty");
//                                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
//                                TableLayout.removeAllViews();
//                            }
//                        }
//
//                        @Override
//                        public void onCancelled(DatabaseError error) {
//                            Log.w(TAG, "onCancelled", error.toException());
//                        }
//                    });
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError error) {
//                Log.w(TAG, "onCancelled", error.toException());
//            }
//        });
//    }
//
//    @Override
//    public void onClick(View v) {
//        if (v.getId() == R.id.Button02) {// Handle checkout button click (implementation depends on your checkout flow)
//            Toast.makeText(Carting.this, "Checkout is not implemented yet", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void updateQuantity(final String pid, final String pname, final int pprice, final TextView textView2) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(Carting.this);
//        builder.setTitle("Update Quantity");
//
//        // Set up the input
//        final EditText input = new EditText(Carting.this);
//        input.setInputType(InputType.TYPE_CLASS_NUMBER);
//        input.setText(textView2.getText().toString());
//        builder.setView(input);
//
//        // Set up the buttons
//        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                String newQuantity = input.getText().toString();
//                if (!newQuantity.isEmpty()) {
//                    int quantity = Integer.parseInt(newQuantity);
//                    updateCartItem(pid, quantity);
//                    textView2.setText(newQuantity); // Update displayed quantity
//                    int productTotal = quantity * pprice;
//                    GTT = GTT - (Integer.parseInt(textView4.getText().toString().replace(".00", ""))) + productTotal;
//                    GrandTotal.setText("Total: " + GTT + " Rs.");
//                    textView4.setText(productTotal + ".00"); // Update displayed total
//                } else {
//                    Toast.makeText(Carting.this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.cancel();
//            }
//        });
//        builder.show();
//    }
//
//    private void updateCartItem(String pid, int quantity) {
//        FirebaseUser user = firebaseAuth.getCurrentUser();
//        if (user != null) {
//            username = user.getUid();
//            databaseReference2 = FirebaseDatabase.getInstance().getReference("Carts").child(username).child(pid);
//            databaseReference2.child("quantity").setValue(quantity);
//            Toast.makeText(Carting.this,  " quantity updated", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(Carting.this, "Please Sign In to use Cart", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void removeItem(String pid) {
//        FirebaseUser user = firebaseAuth.getCurrentUser();
//        if (user != null) {
//            username = user.getUid();
//            databaseReference3 = FirebaseDatabase.getInstance().getReference("Carts").child(username).child(pid);
//            databaseReference3.removeValue();
//            Toast.makeText(Carting.this, "Item removed from cart", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(Carting.this, "Please Sign In to use Cart", Toast.LENGTH_SHORT).show();
//        }
//    }
//}



