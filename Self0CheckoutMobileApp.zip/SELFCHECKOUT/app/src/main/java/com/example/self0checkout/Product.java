package com.example.self0checkout;

public class Product {
    private String id;
    private String name;
    private double price;

    // Constructor(s), getters, setters
    public Product() {
        // Default constructor required for Firebase
    }
    public Product(String id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
