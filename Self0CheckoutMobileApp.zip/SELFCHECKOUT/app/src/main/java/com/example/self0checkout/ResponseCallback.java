package com.example.self0checkout;

public interface ResponseCallback {
    void onResponse(String response);
    void onError(Throwable throwable);
}