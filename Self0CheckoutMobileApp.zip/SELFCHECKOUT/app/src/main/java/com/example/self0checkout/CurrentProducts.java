package com.example.self0checkout;

import android.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class CurrentProducts extends AppCompatActivity {
    private DatabaseReference databaseReference1;
    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_products);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        tableLayout = findViewById(R.id.myTableLayout);

        databaseReference1 = FirebaseDatabase.getInstance().getReference().child("Products");
        databaseReference1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                // Clear the table layout before adding new data
                tableLayout.removeAllViews();

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Product product = postSnapshot.getValue(Product.class);

                    // Create a new table row
                    TableRow tableRow = new TableRow(CurrentProducts.this);

                    // Create text views for each product attribute
                    TextView textView0 = new TextView(CurrentProducts.this);
                    TextView textView1 = new TextView(CurrentProducts.this);
                    TextView textView2 = new TextView(CurrentProducts.this);

                    // Set text for text views
                    textView0.setText(product.getId());
                    textView1.setText(product.getName());
                    textView2.setText(product.getPrice() + " Rs.");

                    // Add text views to the table row
                    tableRow.addView(textView0);
                    tableRow.addView(textView1);
                    tableRow.addView(textView2);

                    // Add table row to the table layout
                    tableLayout.addView(tableRow);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle onCancelled event
            }
        });
    }
}

//package com.example.self0checkout;
//
//import android.app.ActionBar;
//import androidx.appcompat.app.AppCompatActivity;
//import android.os.Bundle;
//import android.widget.TableLayout;
//import android.widget.TableRow;
//import android.widget.TextView;
//
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.Query;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.Objects;
//
//public class CurrentProducts extends AppCompatActivity {
//    private DatabaseReference databaseReference1;
//    private TableLayout tableLayout;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_current_products);
//        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
//
//        tableLayout = findViewById(R.id.myTableLayout);
//
//        databaseReference1 = FirebaseDatabase.getInstance().getReference().child("Products");
//        databaseReference1.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                // Clear the table layout before adding new data
//                tableLayout.removeAllViews();
//
//                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
//                    Product product = postSnapshot.getValue(Product.class);
//
//                    // Create a new table row
//                    TableRow tableRow = new TableRow(CurrentProducts.this);
//
//                    // Create text views for each product attribute
//                    TextView textView0 = new TextView(CurrentProducts.this);
//                    TextView textView1 = new TextView(CurrentProducts.this);
//                    TextView textView2 = new TextView(CurrentProducts.this);
//
//                    // Set text for text views
//                    textView0.setText(product.getId());
//                    textView1.setText(product.getName());
//                    textView2.setText(product.getPrice() + " Rs.");
//
//                    // Add text views to the table row
//                    tableRow.addView(textView0);
//                    tableRow.addView(textView1);
//                    tableRow.addView(textView2);
//
//                    // Add table row to the table layout
//                    tableLayout.addView(tableRow);
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                // Handle onCancelled event
//            }
//        });
//    }
//}