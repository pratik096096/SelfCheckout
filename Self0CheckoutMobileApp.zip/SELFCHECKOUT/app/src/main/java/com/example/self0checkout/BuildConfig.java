package com.example.self0checkout;

public class BuildConfig {
    public static String apiKey = "AIzaSyDlrdDNm2BGFsMRVO6rHpXKExq5xYDyZ0g";
}